import hashlib
import string
import secrets
import pygame
from CollisionGrid import CollisionGrid
from typing import Optional
from Maps import PATHS
from Databases import SOUNDS

_BASE_GAME_W = (1960 - int(1960 * 0.12)) // 2  # 862 px reference
_BASE_GAME_H = 1080
PINK = (255, 128, 255)

class User:
    def __init__(self, username, email):
        self.username = username
        self.email = email
        self.hashpass = ""
        self.salt = ""

    def __str__(self):
        return super().__str__()

    @staticmethod
    def hash_salt_passwd(passwd, salt=None):
        if not salt:
            salt = User.salt_generator()
        both = salt + passwd
        return salt, User.hash_item(both)

    @staticmethod
    def hash_item(item):
        """
        return hashed 256 string
        """
        m = hashlib.sha256()
        m.update(item.encode())
        return m.hexdigest()

    @staticmethod
    def salt_generator(length=16):
        alphabet = string.ascii_letters + string.digits + string.punctuation
        salt = ''.join(secrets.choice(alphabet) for _ in range(length))
        return salt


class GameUser:

    def __init__(self, side, name):
        self.username = name

        self.side = side
        self.monkey_map = {
            "monkey_0": "dart_monkey",
            "monkey_1": "tack_shooter",
            "monkey_2": "sniper_monkey",
            "monkey_3": "bomb_shooter"
        }
        self.lives = 200

        self.money = 10000
        self.eco = 250
        self.eco_timer = 0  # Tracks time until next payout
        self.ECO_INTERVAL = 6000  # 6 seconds in milliseconds
        self.bloons_queue = []
        self.last_send = 0
        self.bloons_list = pygame.sprite.Group()
        self.monkeys_list = pygame.sprite.Group()
        self.grid = CollisionGrid()

        self.send_queue = []

        pygame.mixer.init()

        info = pygame.display.Info()
        self.full_size = [info.current_w, info.current_h]
        self.size = [self.full_size[0], self.full_size[1]]
        self.game_rect = pygame.Rect(0, 0, 0, 0)
        self.path = PATHS[str(side)]

        self.selected_tower: Optional[str] = None
        from Monkey import Monkey
        self.active_monkey: Optional[Monkey] = None

        self.round_bloons = []
        self.round_finished = False
        self.last_round_send = 0

        self.calc_game_rect()


    def update_eco(self, dt):
        self.eco_timer += dt

        if self.eco_timer >= self.ECO_INTERVAL:
            self.money += round(self.eco)
            self.eco_timer = 0  # Reset the clock for the next 6 seconds
            pygame.mixer.Sound(f"assets/sounds/{SOUNDS["cash"]}").play()
            # print(f"Payout! Current Money: {self.money}")

    def check_send(self, curr_time):
        if len(self.bloons_queue) > 0:
            if curr_time - self.last_send >= self.bloons_queue[0][1]:
                self.bloons_list.add(self.bloons_queue.pop(0)[0])
                self.last_send = curr_time

        # 1. Spawn bloons sequentially if the queue has elements
        if len(self.round_bloons) > 0:
            if curr_time - self.last_round_send >= self.round_bloons[0][1]:
                self.bloons_list.add(self.round_bloons.pop(0)[0])
                self.last_round_send = curr_time

        # 2. Executed ONLY when all round bloons have finished spawning from the queue
        else:
            if len(self.bloons_list) == 0 and curr_time > 10000:
                self.round_finished = True
            else:
                self.round_finished = False

    def update(self, dt, current_time, sock):
        # 1. Handle Income Timer
        self.update_eco(dt)

        # 2. Spawn queued bloons
        self.check_send(current_time)

        if len(self.send_queue) > 0:
            active = self.send_queue[0]
            if current_time - active["last_tick"] >= active["load_time"]:
                active["count"] -= 1
                active["last_tick"] = current_time
                if active["count"] <= 0:
                    self.send_queue.pop(0)
                    # Start the timer for the next batch immediately
                    if len(self.send_queue) > 0:
                        self.send_queue[0]["last_tick"] = current_time

        # 3. Collision & Combat
        self.grid.clear()
        for b in self.bloons_list:
            if b.move_bloon(dt):
                if self.username == 'You':
                    self.lives -= b.dmg
                b.kill()
            b.update_bloon_rect(self.game_rect)
            self.grid.insert_bloon(b)

        for m in self.monkeys_list:
            m.move_projectiles(dt, self.game_rect)
            m.update_monkey_rect(self.game_rect)

            # FIX: Let check_shoot run if an ability is active to spawn visual projectiles
            if self.username == 'You' or getattr(m, 'ability_active', False):
                m.check_shoot(current_time, self.bloons_list)

            # Keep hit detection strictly to the local player to avoid double-counting
            if self.username == 'You':
                children, money, hits = m.check_hits(self.grid)
                self.money += money
                if len(children) > 0:
                    for child in children:
                        self.bloons_list.add(child)

                from Game import e_key
                from enc_utils import send_with_size
                for hit in hits:
                    stun_val = hit.get("stun", 0)
                    send_with_size(sock, f"GAME_ACTION~HIT_BLOON~{self.side}~{hit['id']}~{hit['dmg']}~{stun_val}",
                                   e_key)

    def try_purchase(self, cost):
        if self.money >= cost:
            self.money -= cost
            return True  # Purchase successful
        return False  # Too poor!

    def calc_game_rect(self):
        """Dynamically computes the exact screen rectangle for this player's play field."""
        w, h = self.size[0], self.size[1]
        shop_width = int(w * 0.12)
        game_width = (w - shop_width) // 2

        # Define how much vertical space we want to reserve at the top for Username & Lives
        self.header_height = 45

        if self.side == 1:
            # Player 1 occupies the left half of the remaining space
            # We shift the top down by self.header_height and shrink the height accordingly
            self.game_rect = pygame.Rect(shop_width, self.header_height, game_width, h - self.header_height)
        else:
            # Player 2 occupies the right half of the remaining space
            self.game_rect = pygame.Rect(shop_width + game_width, self.header_height, game_width,
                                         h - self.header_height)


